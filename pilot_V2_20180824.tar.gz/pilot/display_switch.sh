#!/bin/bash

if [ ! -d "/boot/pilot/LCD_driver" ];then
echo "/boot/pilot/LCD_driver not exist"
cd /boot/pilot/
sudo unzip LCD_driver.zip
fi

if [ -f "/boot/hdmi_mode" ];then
echo "/boot/hdmi_mode exist"
sudo rm -rf /boot/hdmi_mode
cd /boot/pilot/LCD_driver
sudo ./LCD-hdmi
#else
#echo "/boot/hdmi_mode not exist"
fi

if [ -f "/boot/lcd_mode" ];then
echo "/boot/lcd_mode exist"
sudo rm -rf /boot/lcd_mode
cd /boot/pilot/LCD_driver
sudo ./LCD35_show 180
#else
#echo "/boot/lcd_mode not exist"
fi


#!/bin/bash

cd /boot/pilot/
sudo cp hdmi_mode ../

/boot/pilot/display_switch.sh




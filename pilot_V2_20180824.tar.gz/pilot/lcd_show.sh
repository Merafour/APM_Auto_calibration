#!/bin/bash

cd /boot/pilot/
sudo cp lcd_mode ../

/boot/pilot/display_switch.sh




#!/bin/bash

/boot/pilot/display_switch.sh

cd /boot/pilot/
cp ./pilot /home/pi/Desktop/pilot
cd /home/pi/Desktop/
./pilot &

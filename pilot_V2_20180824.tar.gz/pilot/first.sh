#!/bin/bash

cd /boot/pilot/
cp .profile ~/.profile



